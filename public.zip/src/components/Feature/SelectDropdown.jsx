// import React from 'react'
// import InputLabel from '@mui/material/InputLabel';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';

// const SelectDropdown = (props) => {
//   const [operator, setOperator] = React.useState('');
//   console.log(props.airtalImage)

//   const handleChange = (event) => {
//     setOperator(event.target.value);
//   };
//   return (
//     <FormControl sx={{ m: 1, minWidth: 340 }} size="small">
//       <InputLabel id="demo-select-small-label">{props.titleName}</InputLabel>
//       <Select
//         labelId="demo-select-small-label"
//         id="demo-select-small"
//         value={operator}
//         label="operator"
//         onChange={handleChange}
//         className='customer-drp'
//       >
//         <MenuItem value={10}><img src={''} /> Airtal</MenuItem>
//         <MenuItem value={20}>Jio</MenuItem>
//         <MenuItem value={30}>VI</MenuItem>
//         <MenuItem value={30}>Idea</MenuItem>
//       </Select>
//     </FormControl>
//   )
// }

// export default SelectDropdown
