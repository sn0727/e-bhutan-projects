import React,{useEffect} from 'react'

const PaymentSuccessful = () => {

    return (
        <div>
            <h2>payment successful </h2>
        </div>
    )
}

export default PaymentSuccessful
