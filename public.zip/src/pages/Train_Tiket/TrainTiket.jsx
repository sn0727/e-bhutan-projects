import React from 'react'

const TrainTiket = () => {
  return (
    <div>
      this is component
    </div>
  )
}

export default TrainTiket
